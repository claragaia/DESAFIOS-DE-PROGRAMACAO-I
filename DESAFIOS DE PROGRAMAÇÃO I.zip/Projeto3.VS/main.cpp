// Questão 3.
#include <stdio.h> 

  

int main(){ 

   int altura, opcao; 

  

    printf("Informe a altura do triângulo: "); 

    scanf("%d", &altura); 

  

    printf("1 - Preenchido\n"); 
    printf("2 - Vazado\n"); 
    printf("Escolha a opção 1 ou 2: "); 
    scanf("%d", &opcao); 

  

    for(int i = 1; i <= altura; i++) { 

        for(int j = 1; j <= i; j++) { 

            if(opcao == 1) { 
                printf("*"); 

            } else { 

                if(j == 1 || j == i || i == altura) 
                    printf("*"); 

                else 
                    printf(" "); 

            } 

        } 

        printf("\n"); 

    } 

    return 0; 

} 