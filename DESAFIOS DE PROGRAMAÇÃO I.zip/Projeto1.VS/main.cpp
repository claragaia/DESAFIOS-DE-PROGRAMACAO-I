// Questão 1.
#include <stdio.h>

int main(){

    int altura, largura, opcao;

    printf("Digite a altura: ");
    scanf("%d", &altura);

    printf("Digite a largura: ");
    scanf("%d", &largura);

    printf("\n1 - Retangulo preenchido");
    printf("\n2 - Retangulo vazado");
    printf("\nEscolha uma opcao: ");
    scanf("%d", &opcao);

    for(int i = 0; i < altura; i++){

        for(int j = 0; j < largura; j++){

            // RETANGULO PREENCHIDO
            if(opcao == 1){
                printf("*");
            }

            // RETANGULO VAZADO
            else if(opcao == 2){

                if(i == 0 || i == altura - 1 || j == 0 || j == largura - 1){
                    printf("*");
                }
                else{
                    printf(" ");
                }
            }
        }

        printf("\n");
    }

    return 0;
}