 // Questão 7.
#include <stdio.h> 

  

int main() { 

  

    int N; 

  

    // Ler valor válido 

    do { 

  

        printf("Digite o valor de N: "); 

        scanf("%d", &N); 

  

        if (N < 3) { 

            printf("ERRO! N deve ser maior ou igual a 3. Digite novamente.\n"); 

        } 

  

    } while (N < 3); 

  

    int matriz[N][N]; 

  

    int topo = 0; 

    int baixo = N - 1; 

    int esquerda = 0; 

    int direita = N - 1; 

  

    int valor = 1; 

  

    // Preencher matriz em espiral 

    while (topo <= baixo && esquerda <= direita) { 

  

        // Linha superior 

        for (int j = esquerda; j <= direita; j++) { 

            matriz[topo][j] = valor; 

            valor++; 

        } 

  

        topo++; 

  

        // Coluna direita 

        for (int i = topo; i <= baixo; i++) { 

            matriz[i][direita] = valor; 

            valor++; 

        } 

  

        direita--; 

  

        // Linha inferior 

        for (int j = direita; j >= esquerda; j--) { 

            matriz[baixo][j] = valor; 

            valor++; 

        } 

  

        baixo--; 

  

        // Coluna esquerda 

        for (int i = baixo; i >= topo; i--) { 

            matriz[i][esquerda] = valor; 

            valor++; 

        } 

  

        esquerda++; 

    } 

  

    // Mostrar matriz 

    printf("\nEspiral Quadrada:\n\n"); 

  

    for (int i = 0; i < N; i++) { 

  

        for (int j = 0; j < N; j++) { 

            printf("%3d", matriz[i][j]); 

        } 

  

        printf("\n"); 

    } 

  

    return 0; 

} 