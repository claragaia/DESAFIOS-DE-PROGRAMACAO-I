// Questão 6.
#include <stdio.h>

int main() {

    int B, L, A;
    int i, j;

    // Base
    do {
        printf("Informe a base B: ");
        scanf("%d", &B);

        if (B < 3 || B % 2 == 0) {
            printf("Valor invalido!\n");
        }

    } while (B < 3 || B % 2 == 0);

    // Largura do tronco
    do {
        printf("Informe a largura do tronco L: ");
        scanf("%d", &L);

        if (L < 1 || L % 2 == 0 || L > B / 2) {
            printf("Valor invalido!\n");
        }

    } while (L < 1 || L % 2 == 0 || L > B / 2);

    // Altura do tronco
    do {
        printf("Informe a altura do tronco A: ");
        scanf("%d", &A);

        if (A < 2 || A > B / 2) {
            printf("Valor invalido!\n");
        }

    } while (A < 2 || A > B / 2);

    // Copa da árvore
    for (i = 1; i <= B; i += 2) {

        // Espaços
        for (j = 1; j <= (B - i) / 2; j++) {
            printf(" ");
        }

        // Asteriscos
        for (j = 1; j <= i; j++) {
            printf("*");
        }

        printf("\n");
    }

    // Tronco
    for (i = 1; i <= A; i++) {

        // Centralização
        for (j = 1; j <= (B - L) / 2; j++) {
            printf(" ");
        }

        // Largura do tronco
        for (j = 1; j <= L; j++) {
            printf("*");
        }

        printf("\n");
    }

    return 0;
}