#include <stdio.h> 

  

int main() { 

  

    int n; 

  

    printf("Informe a altura do triângulo: "); 

    scanf("%d", &n); 

  

    int pascal[n][n]; 

  

    // Monta o triangulo 

    for(int i = 0; i < n; i++) { 

  

        for(int j = 0; j <= i; j++) { 

  

            // bordas 

            if(j == 0 || j == i) { 

  

                pascal[i][j] = 1; 

  

            } else { 

  

                pascal[i][j] = pascal[i-1][j-1] + pascal[i-1][j]; 

            } 

        } 

    } 

  

    // Mostra o triangulo 

    printf("\n"); 

  

    for(int i = 0; i < n; i++) { 

  

        // espaços para centralizar 

        for(int esp = 0; esp < n - i; esp++) { 

            printf(" "); 

        } 

  

        for(int j = 0; j <= i; j++) { 

            printf("%d ", pascal[i][j]); 

        } 

  

        printf("\n"); 

    } 

  

    return 0; 

}