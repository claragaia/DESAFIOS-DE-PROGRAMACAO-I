// Questão 4.
#include <stdio.h> 

  

int main() { 

  

    int largura; 

  

    printf("Informe a largura central do losango: "); 

    scanf("%d", &largura); 

  

    int meio = largura / 2; 

  

    // Parte superior 

    for(int i = 0; i <= meio; i++) { 

  

        for(int j = 0; j < meio - i; j++) { 

            printf(" "); 

        } 

  

        for(int j = 0; j < (2 * i + 1); j++) { 

            printf("X"); 

        } 

  

        printf("\n"); 

    } 

  

    // Parte inferior 

    for(int i = meio - 1; i >= 0; i--) { 

  

        for(int j = 0; j < meio - i; j++) { 

            printf(" "); 

        } 

  

        for(int j = 0; j < (2 * i + 1); j++) { 

            printf("X"); 

        } 

  

        printf("\n"); 

    } 

  

    return 0; 

}