// Questão 8.
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Estrutura para representar pontos bidimensionais discretos na matriz
typedef struct {
    int x;
    int y;
} Point;

// Matriz global ou estrutura de tela para facilitar o desenho adaptativo
char **grid;
int grid_width, grid_height;

// Inicializa a matriz com espaços vazios
void init_grid(int w, int h) {
    grid_width = w;
    grid_height = h;
    grid = (char **)malloc(grid_height * sizeof(char *));
    for (int i = 0; i < grid_height; i++) {
        grid[i] = (char *)malloc((grid_width + 1) * sizeof(char));
        for (int j = 0; j < grid_width; j++) {
            grid[i][j] = ' ';
        }
        grid[i][grid_width] = '\0';
    }
}

// Libera a memória alocada para a matriz
void free_grid() {
    for (int i = 0; i < grid_height; i++) {
        free(grid[i]);
    }
    free(grid);
}

// Imprime a matriz na tela
void print_grid() {
    for (int i = 0; i < grid_height; i++) {
        printf("%s\n", grid[i]);
    }
}

// Desenha um ponto na matriz se estiver dentro dos limites
void draw_point(int x, int y) {
    if (x >= 0 && x < grid_width && y >= 0 && y < grid_height) {
        grid[y][x] = '*';
    }
}

// Algoritmo de Linha de Bresenham para desenhar retas perfeitas em matriz de caracteres
void draw_line(int x0, int y0, int x1, int y1) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2;

    while (1) {
        draw_point(x0, y0);
        if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

// Função recursiva da Curva de Koch
void draw_koch_segment(double x0, double y0, double x1, double y1, int level) {
    if (level == 1) {
        // No nível base do nosso traçado, renderiza a reta direta entre os pontos gerados
        draw_line((int)round(x0), (int)round(y0), (int)round(x1), (int)round(y1));
        return;
    }

    // Divisão do segmento em 3 partes iguais
    double dx = (x1 - x0) / 3.0;
    double dy = (y1 - y0) / 3.0;

    // Pontos intermediários que dividem o segmento
    double xA = x0 + dx;
    double yA = y0 + dy;
    
    double xB = x0 + 2.0 * dx;
    double yB = y0 + 2.0 * dy;

    // Calcular o vértice do triângulo equilátero equilátero (ponto saliente)
    // Rotacionamos o vetor (dx, dy) em 60 graus (pi/3 radianos) para fora
    double angle = -M_PI / 3.0; // Sinal negativo define a projeção para o exterior do floco
    double xC = xA + (dx * cos(angle) - dy * sin(angle));
    double yC = yA + (dx * sin(angle) + dy * cos(angle));

    // Recursão para os 4 novos subsegmentos criados
    draw_koch_segment(x0, y0, xA, yA, level - 1);
    draw_koch_segment(xA, yA, xC, yC, level - 1);
    draw_koch_segment(xC, yC, xB, yB, level - 1);
    draw_koch_segment(xB, yB, x1, y1, level - 1);
}

int main() {
    int N;

    // Loop de validação obrigatória para o nível N
    while (1) {
        printf("Digite o nivel N do fractal (1 a 3): ");
        if (scanf("%d", &N) == 1) {
            if (N >= 1 && N <= 3) {
                break; // Entrada válida
            }
        }
        // Limpa o buffer de entrada em caso de digitação de caracteres inválidos
        while (getchar() != '\n'); 
        printf("Erro: Valor invalido. O nivel deve ser obrigatoriamente entre 1 e 3.\n\n");
    }

    // Definição geométrica dinâmica com base no nível N para acomodar o fractal perfeitamente
    // N=1 necessita de menos espaço; N=3 necessita de maior resolução para os detalhes ASCII
    int side_length;
    if (N == 1) {
        side_length = 24;
        init_grid(65, 45);
    } else if (N == 2) {
        side_length = 36;
        init_grid(85, 60);
    } else { // N == 3
        side_length = 54;
        init_grid(115, 85);
    }

    // Centro da matriz para posicionamento do fractal
    double cx = grid_width / 2.0;
    double cy = grid_height / 2.0;

    // Raio do círculo circunscrito para os pontos da estrela base (Estrela de David / 6 pontas)
    double r = side_length * 1.1; 

    // Uma estrela de 6 pontas é formada por dois triângulos equiláteros invertidos sobrepostos
    // Vamos calcular os vértices e disparar os segmentos de Koch para ambos os triângulos

    // Triângulo 1 (Apontando para cima)
    double x1_t1 = cx + r * cos(-M_PI / 2.0);
    double y1_t1 = cy + r * sin(-M_PI / 2.0);
    double x2_t1 = cx + r * cos(-M_PI / 2.0 + 2.0 * M_PI / 3.0);
    double y2_t1 = cy + r * sin(-M_PI / 2.0 + 2.0 * M_PI / 3.0);
    double x3_t1 = cx + r * cos(-M_PI / 2.0 + 4.0 * M_PI / 3.0);
    double y3_t1 = cy + r * sin(-M_PI / 2.0 + 4.0 * M_PI / 3.0);

    // Triângulo 2 (Apontando para baixo)
    double x1_t2 = cx + r * cos(M_PI / 2.0);
    double y1_t2 = cy + r * sin(M_PI / 2.0);
    double x2_t2 = cx + r * cos(M_PI / 2.0 + 2.0 * M_PI / 3.0);
    double y2_t2 = cy + r * sin(M_PI / 2.0 + 2.0 * M_PI / 3.0);
    double x3_t2 = cx + r * cos(M_PI / 2.0 + 4.0 * M_PI / 3.0);
    double y3_t2 = cy + r * sin(M_PI / 2.0 + 4.0 * M_PI / 3.0);

    // Processa e desenha recursivamente as arestas dos dois triângulos sobrepostos
    // Primeiro Triângulo
    draw_koch_segment(x1_t1, y1_t1, x2_t1, y2_t1, N);
    draw_koch_segment(x2_t1, y2_t1, x3_t1, y3_t1, N);
    draw_koch_segment(x3_t1, y3_t1, x1_t1, y1_t1, N);

    // Segundo Triângulo
    draw_koch_segment(x1_t2, y1_t2, x2_t2, y2_t2, N);
    draw_koch_segment(x2_t2, y2_t2, x3_t2, y3_t2, N);
    draw_koch_segment(x3_t2, y3_t2, x1_t2, y1_t2, N);

    // Exibe o resultado final renderizado em ASCII
    print_grid();

    // Limpeza de memória do sistema
    free_grid();

    return 0;
}