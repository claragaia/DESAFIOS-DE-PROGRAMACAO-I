#include <stdio.h>

int main() {

    int N;

    do {
        printf("Informe o nivel N (1 a 3): ");
        scanf("%d", &N);

        if(N < 1 || N > 3) {
            printf("Valor invalido!\n");
        }

    } while(N < 1 || N > 3);

    switch(N) {

        case 1:

            printf("      *\n");
            printf("    * * *\n");
            printf("*************\n");
            printf("*           *\n");
            printf("*           *\n");
            printf("*************\n");
            printf("    * * *\n");
            printf("      *\n");

            break;

        case 2:

            printf("Nivel 2 do floco de neve\n");
            printf("(desenho maior aqui)\n");

            break;

        case 3:

            printf("Nivel 3 do floco de neve\n");
            printf("(desenho ainda maior aqui)\n");

            break;
    }

    return 0;
}