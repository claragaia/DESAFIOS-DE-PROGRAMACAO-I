// Questão 2.

#include <stdio.h>

int main(){

    int N;

    printf("Digite o valor de N: ");
    scanf("%d", &N);

    // Verifica se N é valido
    if(N < 2){
        printf("Erro! N deve ser maior ou igual a 2.\n");
        return 0;
    }

    // Linhas
    for(int i = 1; i <= N; i++){

        // ESPACOS
        for(int j = 1; j <= N - i; j++){
            printf("  ");
        }

        // CRESCENDO
        for(int j = 1; j <= i; j++){
            printf("%d ", j);
        }

        // DECRESCENDO
        for(int j = i - 1; j >= 1; j--){
            printf("%d ", j);
        }

        printf("\n");
    }

    return 0;
}